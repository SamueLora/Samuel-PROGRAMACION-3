import tkinter as tk

def abrir_ventana_home():
    ventana_home = tk.Toplevel()
    ventana_home.title("Home")
    tk.Label(ventana_home, text="Home").pack()

def datosusuario():
    usuario = entry_usuario.get()
    clave = entry_contraseña.get()
    
    if usuario == "luz karime" and clave == "12345":
        app.destroy()  # Cerrar la ventana actual
        abrir_ventana_home()  # Abrir una nueva ventana con el texto "home"
    
app = tk.Tk()
app.title("Login Colegio")
app.geometry("800x400")
app.configure(bg="#F0FEFF")  # Color de fondo de la ventana principal

frame_logo = tk.Frame(app, background="#F0FEFF", bd=0)  # Eliminar el borde del marco
frame_logo.grid(row=0, column=0, padx=10, pady=10, sticky="w")

frame_contenido = tk.Frame(app, bg="#CBFDFF", bd=0, borderwidth=2, relief="groove", highlightthickness=4, pady=65, highlightbackground="blue", highlightcolor="#ACF1F4")  # Eliminar el borde del marco
frame_contenido.grid(row=0, column=1, padx=10, pady=10, sticky="ns")

# Cargar el logo
logo = tk.PhotoImage(file="C:/Users/Biblioteca.DESUF2Z88Y1-55/Desktop/Parcial 3 prog3/logo.png")

label_logo = tk.Label(frame_logo, image=logo, bg="#F0FEFF")  # Color de fondo del label
label_logo.pack(padx=100, pady=100)

tk.Label(frame_contenido, text="Usuario", font=("Arial", 12, "bold"), bg="#CBFDFF").grid(row=0, column=0, padx=110, pady=5, sticky="e")
entry_usuario = tk.Entry(frame_contenido, width="35")
entry_usuario.grid(row=1, column=0, padx=10, pady=5)

tk.Label(frame_contenido, text="Contraseña", font=("Arial", 12, "bold"), bg="#CBFDFF").grid(row=2, column=0, padx=100, pady=5, sticky="e")
entry_contraseña = tk.Entry(frame_contenido, show="•", width="35")
entry_contraseña.grid(row=3, column=0, padx=10, pady=5)
entry_usuario.focus()

boton= tk.Button(frame_contenido, text="Inicio",  width="30", command=datosusuario, bg="#8BFAFF", activebackground="#F0FEFF")
boton.grid(row=4, column=0, padx=10, pady=30)

app.resizable(False, False)

app.mainloop()
